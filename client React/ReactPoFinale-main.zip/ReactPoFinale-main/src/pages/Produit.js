class Produit {
    constructor(idProduit, libelle, code, prix, quantite, disponibilite, categorie) {
      this.idProduit = idProduit;
      this.libelle = libelle;
      this.code = code;
      this.prix = prix;
      this.quantite = quantite;
      this.disponibilite = disponibilite;
      this.categorie = categorie;
    }
  }
  
  export default Produit;