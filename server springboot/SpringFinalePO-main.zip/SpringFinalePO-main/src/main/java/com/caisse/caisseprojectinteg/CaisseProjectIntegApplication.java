package com.caisse.caisseprojectinteg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CaisseProjectIntegApplication {

    public static void main(String[] args) {
        SpringApplication.run(CaisseProjectIntegApplication.class, args);
    }

}
