package com.caisse.caisseprojectinteg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CaisseProjectIntegApplicationTests {

    @Test
    void contextLoads() {
    }

}
